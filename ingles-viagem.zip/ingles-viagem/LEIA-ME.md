# Inglês pra viagem ✈️

App de estudo de inglês para a viagem: cronograma diário até o embarque (Duolingo + aula + podcast), 36 aulas com 180 frases em áudio, testes de nivelamento, semanais e final, gráfico de evolução, sequência de dias, XP, níveis e frases motivadoras.

Funciona sozinho (o progresso fica salvo no navegador). O Firebase é opcional e serve para sincronizar celular e computador.

## Estrutura

```
public/index.html   → o app inteiro (HTML, CSS e JS num arquivo só)
firebase.json       → configuração do Firebase Hosting e do Firestore
firestore.rules     → regras de segurança (cada pessoa só vê o próprio progresso)
```

## 1. Subir no GitHub

1. Crie um repositório novo no GitHub (por exemplo, `ingles-viagem`).
2. Envie os arquivos desta pasta:
   ```bash
   git init
   git add .
   git commit -m "App de inglês para a viagem"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/ingles-viagem.git
   git push -u origin main
   ```
   Se preferir sem terminal: no GitHub, clique em "Add file" > "Upload files" e arraste os arquivos.

## 2. Publicar no Firebase Hosting

1. Instale a ferramenta (uma vez só): `npm install -g firebase-tools`
2. Entre na sua conta: `firebase login`
3. Dentro da pasta do projeto, ligue ao seu projeto: `firebase use --add` (escolha o projeto e dê o apelido `default`)
4. Publique: `firebase deploy`

O endereço do app aparece no final (algo como `https://seu-projeto.web.app`). Abra no celular e use "Adicionar à tela inicial" para ele ficar como um aplicativo.

**Deploy automático pelo GitHub (opcional):** rode `firebase init hosting:github`. A partir daí, cada `git push` publica o app sozinho.

## 3. Ativar a sincronização entre aparelhos (opcional)

1. No Console do Firebase, abra **Authentication > Sign-in method** e ative **Google**.
2. Em **Authentication > Settings > Authorized domains**, confirme que o domínio do app (`seu-projeto.web.app`) está na lista.
3. Abra **Firestore Database** e crie o banco (modo produção).
4. Em **Configurações do projeto > Seus apps**, crie um app Web e copie o objeto `firebaseConfig`.
5. No `public/index.html`, logo no início do `<script>`, troque `const FIREBASE_CONFIG = null;` pela configuração copiada:
   ```js
   const FIREBASE_CONFIG = {
     apiKey: "...",
     authDomain: "seu-projeto.firebaseapp.com",
     projectId: "seu-projeto",
     appId: "..."
   };
   ```
6. Rode `firebase deploy` de novo (ele publica o app e as regras do Firestore).
7. No app, vá em **Evolução > Sincronizar entre aparelhos > Entrar com Google**.

A chave `apiKey` do Firebase pode ficar no código público: quem protege os dados são as regras do `firestore.rules`.

## Como o cronograma funciona

| Período | Conteúdo |
|---|---|
| Semana 1 (5 a 11/out) | O básico: cumprimentos, apresentações, números, horas |
| Semana 2 (12 a 18/out) | Aeroporto, avião, imigração e bagagem |
| Semana 3 (19 a 25/out) | Hotel, metrô, táxi, ônibus |
| Semana 4 (26/out a 1/nov) | Cafeteria, restaurante, conta, bebidas |
| Semana 5 (2 a 8/nov) | Direções, compras, pagamento, passeios |
| Semana 6 (9 a 15/nov) | Conversa, frio, farmácia, emergências |
| 16 a 18/nov | Revisões gerais |
| 19/nov | Teste final |
| 20/nov | Embarque ✈️ |

De segunda a sábado há uma aula nova; aos domingos, o teste da semana. Todo dia tem Duolingo e um podcast. O dia ganha um carimbo quando as três tarefas são concluídas.

Para mudar a data da viagem, o destino ou o nome, use **Evolução > Configurações**. O cronograma se ajusta sozinho.

## Dicas

- O áudio usa a voz do próprio navegador. No celular, Chrome (Android) e Safari (iPhone) têm vozes em inglês boas.
- Use **Baixar backup** de vez em quando se não ativar o Firebase.
